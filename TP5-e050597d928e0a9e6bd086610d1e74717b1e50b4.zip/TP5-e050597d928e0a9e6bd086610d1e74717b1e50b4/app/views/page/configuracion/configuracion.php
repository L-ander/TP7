<link rel="stylesheet" href="public/css/home.css">
<style>
    .config-tabs { margin-bottom: 20px; }
    .config-tabs > li > a { font-weight: bold; color: #555; }
    .config-tabs > li.active > a { color: #009688; }
    .config-toolbar { margin-bottom: 15px; }
    .config-toolbar .btn { margin-right: 8px; }
</style>
<section class="content">
    <div class="container-fluid">
        <div class="bloque-encabezado">
            <h2>Configuración</h2>
        </div>
        
        <div class="card">
            <div class="header">
                <ul class="nav nav-tabs config-tabs" role="tablist">


                    <li><a href="producto"><i class="material-icons" style="font-size: 24px;">arrow_back</i></a></li>
                    <li role="presentation" class="active"><a href="#configCategorias" data-toggle="tab"><i class="material-icons">category</i> Categorías</a></li>
                    <li role="presentation"><a href="#configSubcategorias" data-toggle="tab"><i class="material-icons">account_tree</i> Subcategorías</a></li>
                    <li role="presentation"><a href="#tab_lineas" data-toggle="tab"><i class="material-icons">layers</i> Líneas de Producto</a></li>
                    <li role="presentation"><a href="#tab_presentaciones" data-toggle="tab"><i class="material-icons">style</i> Presentaciones</a></li>
                    <li role="presentation"><a href="#configMedidas" data-toggle="tab"><i class="material-icons">straighten</i> Und. de medida</a></li>
                    
                    <!-- <li role="presentation"><a href="vendedores#usuarios"><i class="material-icons">manage_accounts</i> Usuario / Personal</a></li>  -->
                </ul>
                
            </div>
            <div class="body tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="configMedidas">
                    <div class="config-toolbar"><button class="btn btn-success js-nueva-config" data-tabla="unidad_medida"><i class="material-icons">add</i> Nueva unidad</button></div>
                    <div class="table-responsive"><table class="table table-bordered table-striped" id="tablaMedidas"><thead><tr><th>ID</th><th>Unidad</th><th>Acciones</th></tr></thead><tbody></tbody></table></div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="configCategorias">
                    <div class="config-toolbar"><button class="btn btn-success js-nueva-config" data-tabla="categoria"><i class="material-icons">add</i> Nueva categoría</button></div>
                    <div class="table-responsive"><table class="table table-bordered table-striped" id="tablaCategorias"><thead><tr><th>ID</th><th>Nombre</th><th>Acciones</th></tr></thead><tbody></tbody></table></div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="configSubcategorias">
                    <div class="config-toolbar"><button class="btn btn-success js-nueva-config" data-tabla="subcategoria"><i class="material-icons">add</i> Nueva subcategoría</button></div>
                    <div class="table-responsive"><table class="table table-bordered table-striped" id="tablaSubcategorias"><thead><tr><th>ID</th><th>Categoría</th><th>Subcategoría</th><th>Acciones</th></tr></thead><tbody></tbody></table></div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="tab_lineas">
                    <div class="config-toolbar"><button class="btn btn-success js-nueva-pl" data-tabla="linea_producto"><i class="material-icons">add</i> Nueva Línea de Producto</button></div>
                    <div class="table-responsive"><table class="table table-bordered table-striped" id="tablaLineas"><thead><tr><th>ID</th><th>Subcategoría</th><th>Nombre</th><th>Opciones</th></tr></thead><tbody></tbody></table></div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="tab_presentaciones">
                    <div class="config-toolbar"><button class="btn btn-success js-nueva-pl" data-tabla="presentacion"><i class="material-icons">add</i> Nueva Presentación</button></div>
                    <div class="table-responsive"><table class="table table-bordered table-striped" id="tablaPresentaciones"><thead><tr><th>ID</th><th>Contenido</th><th>Opciones</th></tr></thead><tbody></tbody></table></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal existente de configuración -->
<div class="modal fade" id="modalConfiguracion" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document"><div class="modal-content">
        <div class="modal-header"><h4 class="modal-title" id="tituloConfiguracion">Nuevo registro</h4></div>
        <div class="modal-body">
            <form id="formConfiguracion">
                <input type="hidden" id="configId"><input type="hidden" id="configTabla">
                <div id="grupoCategoria" class="form-group" style="display:none;"><label for="id_categoria">Categoría</label><select class="form-control" id="id_categoria" required></select></div>
                <div class="form-group"><label for="configNombre">Nombre</label><input type="text" class="form-control" id="configNombre" maxlength="50" required></div>
            </form>
        </div>
        <div class="modal-footer"><button type="submit" form="formConfiguracion" class="btn btn-success">GUARDAR</button><button type="button" class="btn btn-default" data-dismiss="modal">CANCELAR</button></div>
    </div></div>
</div>

<?php include 'app/views/page/inventario/modal_presentacion_linea.php'; ?>
<script src="public/js/configuracion.js"></script>
<script src="public/js/presentacion_linea.js"></script>